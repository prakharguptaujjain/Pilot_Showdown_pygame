
# class QuadTree:
#     """A class implementing a quadtree."""

#     def __init__(self, boundary, max_points=4, depth=0):
#         """Initialize this node of the quadtree.

#         boundary is a Rect object defining the region from which points are
#         placed into this node; max_points is the maximum number of points the
#         node can hold before it must divide (branch into four more nodes);
#         depth keeps track of how deep into the quadtree this node lies.

#         """

#         self.boundary = boundary
#         self.max_points = max_points
#         self.points = []
#         self.depth = depth
#         # A flag to indicate whether this node has divided (branched) or not.
#         self.divided = False

#     def __str__(self):
#         """Return a string representation of this node, suitably formatted."""
#         sp = ' ' * self.depth * 2
#         s = str(self.boundary) + '\n'
#         s += sp + ', '.join(str(point) for point in self.points)
#         if not self.divided:
#             return s
#         return s + '\n' + '\n'.join([
#                 sp + 'nw: ' + str(self.nw), sp + 'ne: ' + str(self.ne),
#                 sp + 'se: ' + str(self.se), sp + 'sw: ' + str(self.sw)])

#     def divide(self):
#         """Divide (branch) this node by spawning four children nodes."""

#         cx, cy = self.boundary.cx, self.boundary.cy
#         w, h = self.boundary.w / 2, self.boundary.h / 2
#         # The boundaries of the four children nodes are "northwest",
#         # "northeast", "southeast" and "southwest" quadrants within the
#         # boundary of the current node.
#         self.nw = QuadTree(Rect(cx - w/2, cy - h/2, w, h),
#                                     self.max_points, self.depth + 1)
#         self.ne = QuadTree(Rect(cx + w/2, cy - h/2, w, h),
#                                     self.max_points, self.depth + 1)
#         self.se = QuadTree(Rect(cx + w/2, cy + h/2, w, h),
#                                     self.max_points, self.depth + 1)
#         self.sw = QuadTree(Rect(cx - w/2, cy + h/2, w, h),
#                                     self.max_points, self.depth + 1)
#         self.divided = True

#     def insert(self, point):
#         """Try to insert Point point into this QuadTree."""

#         if not self.boundary.contains(point):
#             # The point does not lie inside boundary: bail.
#             return False
#         if len(self.points) < self.max_points:
#             # There's room for our point without dividing the QuadTree.
#             self.points.append(point)
#             return True

#         # No room: divide if necessary, then try the sub-quads.
#         if not self.divided:
#             self.divide()

#         return (self.ne.insert(point) or
#                 self.nw.insert(point) or
#                 self.se.insert(point) or
#                 self.sw.insert(point))

#     def query(self, boundary, found_points):
#         """Find the points in the quadtree that lie within boundary."""

#         if not self.boundary.intersects(boundary):
#             # If the domain of this node does not intersect the search
#             # region, we don't need to look in it for points.
#             return False

#         # Search this node's points to see if they lie within boundary ...
#         for point in self.points:
#             if boundary.contains(point):
#                 found_points.append(point)
#         # ... and if this node has children, search them too.
#         if self.divided:
#             self.nw.query(boundary, found_points)
#             self.ne.query(boundary, found_points)
#             self.se.query(boundary, found_points)
#             self.sw.query(boundary, found_points)
#         return found_points


#     def query_circle(self, boundary, centre, radius, found_points):
#         """Find the points in the quadtree that lie within radius of centre.

#         boundary is a Rect object (a square) that bounds the search circle.
#         There is no need to call this method directly: use query_radius.

#         """

#         if not self.boundary.intersects(boundary):
#             # If the domain of this node does not intersect the search
#             # region, we don't need to look in it for points.
#             return False

#         # Search this node's points to see if they lie within boundary
#         # and also lie within a circle of given radius around the centre point.
#         for point in self.points:
#             if (boundary.contains(point) and
#                     point.distance_to(centre) <= radius):
#                 found_points.append(point)

#         # Recurse the search into this node's children.
#         if self.divided:
#             self.nw.query_circle(boundary, centre, radius, found_points)
#             self.ne.query_circle(boundary, centre, radius, found_points)
#             self.se.query_circle(boundary, centre, radius, found_points)
#             self.sw.query_circle(boundary, centre, radius, found_points)
#         return found_points

#     def query_radius(self, centre, radius, found_points):
#         """Find the points in the quadtree that lie within radius of centre."""

#         # First find the square that bounds the search circle as a Rect object.
#         boundary = Rect(*centre, 2*radius, 2*radius)
#         return self.query_circle(boundary, centre, radius, found_points)


#     def __len__(self):
#         """Return the number of points in the quadtree."""

#         npoints = len(self.points)
#         if self.divided:
#             npoints += len(self.nw)+len(self.ne)+len(self.se)+len(self.sw)
#         return npoints

#     def draw(self, ax):
#         """Draw a representation of the quadtree on Matplotlib Axes ax."""

#         self.boundary.draw(ax)
#         if self.divided:
#             self.nw.draw(ax)
#             self.ne.draw(ax)
#             self.se.draw(ax)
#             self.sw.draw(ax)